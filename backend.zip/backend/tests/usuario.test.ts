describe("Atualização de Usuário", () => {
    beforeAll(()=>{

    })
    
    it("deve retornar erro se o nome não for informado", () => {
        // Implementação do teste aqui
    });
});
